# ALAM AI Voice Studio — Android starter v1

A functional Kotlin Android client and FastAPI TTS proxy. The client supports Bengali text, Google TTS / ElevenLabs selection, eight **style presets**, emotion presets, preview, MP3 save, and Android share. The style presets are **not eight distinct trained voices**. Baby/cartoon styles in free mode are pitch adjustments, and premium mode uses the configured male/female voice IDs. Auto emotion tags are metadata mapped to supported settings, not spoken bracketed text. Rain/flute checkboxes are **UI previews only** in this release: music mixing is not implemented.

## GitHub APK build

1. Create a new GitHub repository and upload **the extracted contents** of this project, including `.github/workflows/android.yml`.
2. Go to **Actions > Build Android APK > Run workflow**, or push to `main`.
3. After a successful run, download artifact **ALAM-AI-Voice-Studio-debug** and install its `app-debug.apk` on your phone. It is a debug build, not a signed Play Store release.
4. A server is required for generating audio; the APK alone cannot call paid APIs.

## Backend setup

Python 3.10+:

```bash
cd backend
pip install -r requirements.txt
cp .env.example .env
# Set environment variables in your hosting provider; .env is a reference, not auto-loaded.
uvicorn main:app --host 0.0.0.0 --port 8000
```

Deploy the backend behind HTTPS (e.g. on a Python-compatible hosting service). Configure `APP_ACCESS_PIN`, `GOOGLE_TTS_API_KEY`, `ELEVENLABS_API_KEY`, and ElevenLabs voice IDs as environment variables **on the server**. Do not commit credentials or place them in the APK. Google Cloud billing and API enablement are required even when within applicable free usage limits. ElevenLabs premium requests incur provider usage/plan limits.

In the Android app, enter the HTTPS backend URL and your access code, then generate. Only the URL is saved; the access code is kept in memory for that app session.

## Security / limitations

This is a personal-use starter, not a production multiuser service. The shared access code is a basic gate, not user authentication; it can be copied by anyone you share it with. Rate limiting is per IP, in memory, and resets on server restart. For public deployment, add per-user authentication, quotas, persistent usage tracking, abuse controls, and billing protection. API error bodies are not returned verbatim to the user. Avoid storing sensitive poems on third-party services without consent. Audio synthesis is online only. Bengali voice availability and expressive emotion vary by provider/model. No claim of native crying or baby voice is made.


## Recorder MP3 processing (new)
The recorder records locally to AAC/M4A. MP3 conversion, noise reduction, echo and optional synthetic ambience require the configured HTTPS backend and access code. The backend requires the `ffmpeg` binary with `libmp3lame` enabled on PATH. Install e.g. `apt-get install ffmpeg` on the backend host. It processes a recording sent to `/process-recording` (max 20 MB, maximum output duration 10 minutes), returning MP3 bytes. Recordings are held only in temporary backend storage during conversion. Rain uses synthetic pink-noise ambience, and the musical tone is a sine tone; neither is an authentic rain recording or bamboo flute. The effects are experimental and require listening tests. No Android APK build or on-device testing was performed here.
