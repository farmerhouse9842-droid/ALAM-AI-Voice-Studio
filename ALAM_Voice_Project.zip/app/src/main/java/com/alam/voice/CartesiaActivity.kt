package com.alam.voice

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.net.Uri
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.File
import java.util.concurrent.Executors

/** Experimental direct Cartesia TTS. Keys are never saved or logged. */
class CartesiaActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private var lastFile: File? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 30, 28, 20) }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        fun label(s:String) { root.addView(TextView(this).apply { text=s; textSize=18f; setTextColor(Color.DKGRAY }) }
        fun field(hint:String, multi:Boolean=false):EditText = EditText(this).apply {
            this.hint=hint; if(multi) minLines=4
            root.addView(this)
        }
        fun action(s:String, callback:()->Unit) { root.addView(Button(this).apply { text=s; setOnClickListener { callback() } }) }
        label("Cartesia AI - Text to Speech")
        label("Enter your own API key. It stays in memory only, and is not saved.")
        val key=field("Cartesia API key")
        key.inputType=129
        val voice=field("Voice ID from Cartesia Voices")
        val language=Spinner(this).apply { adapter=ArrayAdapter(this@CartesiaActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("bn","en","hi","ur")); root.addView(this) }
        val words=field("Text to speak",true)
        val status=TextView(this).apply { gravity=Gravity.CENTER_VERTICAL; root.addView(this) }
        action("Generate Cartesia WAV") {
            val apiKey=key.text.toString().trim(); val voiceId=voice.text.toString().trim(); val input=words.text.toString(); val selectedLanguage=language.selectedItem.toString()
            if(apiKey.isEmpty() || voiceId.isEmpty() || input.isBlank()) { status.text="API key, voice ID and text required"; return@action }
            status.text="Generating..."
            worker.execute {
                var connection:HttpURLConnection?=null
                try {
                    connection=(URL("https://api.cartesia.ai/tts/bytes").openConnection() as HttpURLConnection).apply {
                        requestMethod="POST"; connectTimeout=20000; readTimeout=90000; doOutput=true
                        setRequestProperty("Content-Type","application/json")
                        setRequestProperty("X-API-Key",apiKey)
                        setRequestProperty("Cartesia-Version","2025-04-16")
                    }
                    val body=JSONObject().apply {
                        put("model_id","sonic-3"); put("transcript",input)
                        put("voice",JSONObject().put("mode","id").put("id",voiceId))
                        put("language",selectedLanguage)
                        put("output_format",JSONObject().put("container","wav").put("encoding","pcm_s16le").put("sample_rate",44100))
                    }
                    connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    val code=connection.responseCode
                    if(code !in 200..299) {
                        val error=connection.errorStream?.bufferedReader()?.use { it.readText().take(600) } ?: "Unknown API error"
                        runOnUiThread { status.text="Cartesia HTTP $code: $error" }
                    } else {
                        val data=connection.inputStream.use { it.readBytes() }
                        if(data.isEmpty()) throw IllegalStateException("Empty audio response")
                        val f=File(cacheDir,"cartesia_${System.currentTimeMillis()}.wav")
                        f.writeBytes(data)
                        runOnUiThread { lastFile=f; status.text="Audio generated (${data.size} bytes). Tap Save WAV." }
                    }
                } catch(e:Exception) { runOnUiThread { status.text="Request failed: ${e.message}" } }
                finally { connection?.disconnect() }
            }
        }
        action("Save WAV") {
            if(lastFile==null) { status.text="Generate audio first"; return@action }
            startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type="audio/wav"; putExtra(Intent.EXTRA_TITLE, "alam_cartesia.wav")
            },77)
        }
        label("Voice cloning: create a voice in your authorized Cartesia dashboard, then paste its Voice ID here. Free-plan eligibility depends on your account.")
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==77 && resultCode==RESULT_OK) {
            val uri:Uri=data?.data ?: return
            val file=lastFile ?: return
            try { contentResolver.openOutputStream(uri)?.use { output -> file.inputStream().use { it.copyTo(output) } } }
            catch(e:Exception) { Toast.makeText(this,"Save failed: ${e.message}",Toast.LENGTH_LONG).show() }
        }
    }
    override fun onDestroy() { worker.shutdownNow(); super.onDestroy() }
}
