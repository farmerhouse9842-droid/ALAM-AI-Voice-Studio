package com.alam.voice

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File

class AudioProvider: ContentProvider() {
    override fun onCreate()=true
    override fun getType(uri:Uri)="audio/mpeg"
    override fun query(uri:Uri,projection:Array<out String>?,selection:String?,selectionArgs:Array<out String>?,sortOrder:String?):Cursor {
        val cols=arrayOf(OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE)
        return MatrixCursor(cols).apply { addRow(arrayOf("alam_recitation.mp3",File(context!!.cacheDir,"shared_recitation.mp3").length())) }
    }
    override fun openFile(uri:Uri,mode:String):ParcelFileDescriptor {
        if(uri.path!="/shared_recitation.mp3" || mode!="r") throw java.io.FileNotFoundException()
        return ParcelFileDescriptor.open(File(context!!.cacheDir,"shared_recitation.mp3"),ParcelFileDescriptor.MODE_READ_ONLY)
    }
    override fun insert(uri:Uri,values:ContentValues?):Uri?=null
    override fun delete(uri:Uri,selection:String?,selectionArgs:Array<out String>?):Int=0
    override fun update(uri:Uri,values:ContentValues?,selection:String?,selectionArgs:Array<out String>?):Int=0
}
