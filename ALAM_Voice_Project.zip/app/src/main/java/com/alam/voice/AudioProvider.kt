package com.alam.voice

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File

class AudioProvider: ContentProvider() {
    override fun onCreate()=true
    override fun getType(uri:Uri)=if(uri.path=="/shared_recording.m4a") "audio/mp4" else "audio/mpeg"
    override fun query(uri:Uri,projection:Array<out String>?,selection:String?,selectionArgs:Array<out String>?,sortOrder:String?):Cursor {
        val cols=arrayOf(OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE)
        val name=when(uri.path) { "/shared_recording.m4a" -> "shared_recording.m4a"; "/shared_processed.mp3" -> "shared_processed.mp3"; else -> "shared_recitation.mp3" }
        return MatrixCursor(cols).apply { addRow(arrayOf(name,File(context!!.cacheDir,name).length())) }
    }
    override fun openFile(uri:Uri,mode:String):ParcelFileDescriptor {
        val name=when(uri.path) { "/shared_recitation.mp3" -> "shared_recitation.mp3"; "/shared_recording.m4a" -> "shared_recording.m4a"; "/shared_processed.mp3" -> "shared_processed.mp3"; else -> throw java.io.FileNotFoundException() }
        if(mode!="r") throw java.io.FileNotFoundException()
        return ParcelFileDescriptor.open(File(context!!.cacheDir,name),ParcelFileDescriptor.MODE_READ_ONLY)
    }
    override fun insert(uri:Uri,values:ContentValues?):Uri?=null
    override fun delete(uri:Uri,selection:String?,selectionArgs:Array<out String>?):Int=0
    override fun update(uri:Uri,values:ContentValues?,selection:String?,selectionArgs:Array<out String>?):Int=0
}
