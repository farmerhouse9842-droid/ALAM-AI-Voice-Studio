package com.alam.voice

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var poem: EditText
    private lateinit var urlField: EditText
    private lateinit var codeField: EditText
    private lateinit var status: TextView
    private lateinit var mode: Spinner
    private lateinit var voice: Spinner
    private lateinit var emotion: Spinner
    private lateinit var tags: CheckBox
    private lateinit var rain: CheckBox
    private lateinit var flute: CheckBox
    private var audio: ByteArray? = null
    private var player: MediaPlayer? = null
    private val voices = arrayOf("Deep Male", "Emotional Male", "Funny Voice", "Baby Voice", "Cartoon Voice", "Female Voice", "Old Man Voice", "Narrator Voice")
    private val emotions = arrayOf("Nostalgic", "Sad", "Crying", "Happy", "Funny", "Calm")
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,24,22,22); setBackgroundColor(Color.rgb(245,248,253)) }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        fun title(s:String) { root.addView(TextView(this).apply { text=s; textSize=22f; setTextColor(Color.rgb(20,50,90)); setPadding(0,10,0,12) }) }
        fun label(s:String) { root.addView(TextView(this).apply { text=s; textSize=15f; setTextColor(Color.DKGRAY); setPadding(0,12,0,5) }) }
        fun field(hint:String, value:String="", lines:Int=1):EditText = EditText(this).apply { this.hint=hint; setText(value); minLines=lines; if(lines>1) gravity=Gravity.TOP; root.addView(this,LinearLayout.LayoutParams(-1,-2)) }
        fun spinner(items:Array<String>):Spinner = Spinner(this).apply { adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items); root.addView(this) }
        fun button(s:String, action:()->Unit) { root.addView(Button(this).apply { text=s; setOnClickListener { action() } },LinearLayout.LayoutParams(-1,-2)) }
        title("ALAM AI Voice Studio")
        label("বাংলা কবিতা / লেখা")
        poem=field("এখানে বাংলা কবিতা লিখুন", "বাবারা... তোমরা বড় হয়ো না! বৃষ্টিতে ভিজে নাও, প্রাণ খুলে হাসো।", 5)
        label("Voice Mode")
        mode=spinner(arrayOf("Free - Google TTS", "Premium - ElevenLabs"))
        label("Voice Collection")
        voice=spinner(voices)
        label("Emotion")
        emotion=spinner(emotions)
        tags=CheckBox(this).apply { text="Auto Emotion Tags (preview)"; isChecked=true; root.addView(this) }
        rain=CheckBox(this).apply { text="Rain ambience (preview only)"; root.addView(this) }
        flute=CheckBox(this).apply { text="Bamboo flute (preview only)"; root.addView(this) }
        label("Backend HTTPS URL")
        urlField=field("https://your-server.example",prefs.getString("url", "") ?: "")
        label("Access code (kept on this phone)")
        codeField=field("Backend access code")
        button("Save server settings") { prefs.edit().putString("url",urlField.text.toString().trim()).apply(); status.text="Server URL saved. Access code is not saved." }
        button("Generate AI Voice") { generate() }
        button("Play / Stop") { playOrStop() }
        button("Save MP3") { if(audio==null) status.text="Generate audio first" else startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="audio/mpeg"; putExtra(Intent.EXTRA_TITLE,"alam_recitation.mp3") },42) }
        button("Share MP3") { shareAudio() }
        status=TextView(this).apply { text="Ready. Configure your backend to generate voice."; setPadding(0,18,0,20); textSize=14f; root.addView(this) }
        label("Note: Funny/Baby/Cartoon are voice styles, not guaranteed native API voices. Music checkboxes are planned, not mixed into this version.")
    }
    private fun generate() {
        val base=urlField.text.toString().trim().trimEnd('/')
        val code=codeField.text.toString()
        val input=poem.text.toString().trim()
        if(!base.startsWith("https://") || code.isBlank() || input.isBlank()) { status.text="Enter HTTPS server URL, access code and text"; return }
        val selected=voice.selectedItemPosition
        val payload=JSONObject().put("text",input).put("mode",if(mode.selectedItemPosition==0) "free" else "premium")
            .put("voice",if(selected==5) "female" else "male").put("style",voices[selected].lowercase().replace(' ','_'))
            .put("emotion",emotions[emotion.selectedItemPosition].lowercase()).put("auto_tags",tags.isChecked)
        status.text="Generating..."
        executor.execute {
            try {
                val conn=(URL("$base/synthesize").openConnection() as HttpURLConnection).apply {
                    requestMethod="POST"; connectTimeout=15000; readTimeout=120000; doOutput=true
                    setRequestProperty("Content-Type","application/json; charset=utf-8")
                    setRequestProperty("X-Access-Code",code)
                }
                conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val result=if(conn.responseCode in 200..299) conn.inputStream.use { it.readBytes() } else throw Exception("Server returned HTTP ${conn.responseCode}: ${conn.errorStream?.bufferedReader()?.readText()?.take(180)}")
                conn.disconnect()
                runOnUiThread { audio=result; status.text="Audio ready (${result.size/1024} KB). Play or save MP3." }
            } catch(e:Exception) { runOnUiThread { status.text="Failed: ${e.message}" } }
        }
    }
    private fun playOrStop() {
        if(player!=null) { player?.release(); player=null; status.text="Stopped"; return }
        val bytes=audio ?: run { status.text="Generate audio first"; return }
        try {
            val file=java.io.File(cacheDir,"preview.mp3"); file.writeBytes(bytes)
            player=MediaPlayer().apply { setDataSource(file.absolutePath); prepare(); setOnCompletionListener { it.release(); player=null }; start() }
            status.text="Playing"
        } catch(e:Exception) { status.text="Playback failed: ${e.message}" }
    }
    private fun shareAudio() {
        val bytes=audio ?: run { status.text="Generate audio first"; return }
        try {
            val file=java.io.File(cacheDir,"shared_recitation.mp3"); file.writeBytes(bytes)
            // Use a content provider rather than exposing a file:// URI.
            val uri=Uri.parse("content://${packageName}.audio/shared_recitation.mp3")
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type="audio/mpeg"; putExtra(Intent.EXTRA_STREAM,uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) },"Share audio"))
        } catch(e:Exception) { status.text="Share failed: ${e.message}" }
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==42 && resultCode==RESULT_OK) {
            val bytes=audio ?: return
            try { data?.data?.let { contentResolver.openOutputStream(it)?.use { out->out.write(bytes) } }; status.text="MP3 saved" }
            catch(e:Exception) { status.text="Save failed: ${e.message}" }
        }
    }
    override fun onDestroy() { player?.release(); executor.shutdownNow(); super.onDestroy() }
}
