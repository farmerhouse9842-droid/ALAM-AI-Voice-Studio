package com.alam.voice

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 12, 32)
    private val panel = Color.rgb(20, 29, 62)
    private val cyan = Color.rgb(29, 218, 243)
    private fun dp(n:Int) = (n * resources.displayMetrics.density + .5f).toInt()
    private fun shape(color:Int, radius:Int=18) = GradientDrawable().apply { setColor(color); cornerRadius=dp(radius).toFloat() }
    private fun text(t:String,size:Float,bold:Boolean=false,color:Int=Color.WHITE) = TextView(this).apply {
        text=t; textSize=size; setTextColor(color); gravity=Gravity.CENTER_VERTICAL
        if(bold) setTypeface(null,Typeface.BOLD)
    }
    private fun space(parent:LinearLayout,n:Int) { parent.addView(android.view.View(this), LinearLayout.LayoutParams(1,dp(n))) }
    private fun launch(cls:Class<out Activity>) { startActivity(Intent(this,cls)) }
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor=bg; window.navigationBarColor=bg
        val scroll=ScrollView(this).apply { setBackgroundColor(bg); isFillViewport=true }
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(18),dp(16),dp(24)) }
        scroll.addView(root);setContentView(scroll)
        val header=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL }
        val portrait=ImageView(this).apply { setImageResource(R.drawable.alam_portrait); scaleType=ImageView.ScaleType.CENTER_CROP; background=shape(panel,16); clipToOutline=true }
        header.addView(portrait,LinearLayout.LayoutParams(dp(64),dp(68)))
        val headings=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),0,0,0) }
        headings.addView(text("ALAM",26f,true,cyan));headings.addView(text("AI Voice Studio",20f,true));headings.addView(text("Create • Clone • Speak",12f,false,Color.rgb(247,206,94)))
        header.addView(headings,LinearLayout.LayoutParams(0,-2,1f));root.addView(header)
        space(root,18)
        val hero=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(18),dp(18),dp(18));background=shape(Color.rgb(39,31,115)) }
        hero.addView(text("🎙  Cartesia AI Voice",22f,true));space(hero,6)
        hero.addView(text("Text to Speech • বাংলা • English • हिन्दी • اردو",13f))
        space(hero,14)
        val open=Button(this).apply { text="OPEN AI VOICE  ›";setTextColor(Color.WHITE);background=shape(Color.rgb(0,150,173));setOnClickListener { launch(CartesiaActivity::class.java) } }
        hero.addView(open,LinearLayout.LayoutParams(-1,dp(52)));root.addView(hero)
        space(root,18);root.addView(text("Your studio",19f,true));space(root,10)
        val actions=listOf(
            Triple("🎤","Record Voice","Record and save audio"),
            Triple("🔊","AI Voice","Cartesia TTS"),
            Triple("🧬","Voice Clone","Use your own Voice ID"),
            Triple("✨","Audio Studio","Noise and echo tools"),
            Triple("🎵","MP3 Tools","Process and export"),
            Triple("📤","Share Audio","Save and share files")
        )
        for(row in 0..2) {
            val line=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            for(col in 0..1) {
                val index=row*2+col;val a=actions[index]
                val tile=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(6),dp(13),dp(6),dp(13));background=shape(if(index%3==0)Color.rgb(71,25,83) else if(index%3==1)Color.rgb(24,53,112) else Color.rgb(15,67,77)) }
                tile.addView(text(a.first,27f).apply { gravity=Gravity.CENTER })
                space(tile,5);tile.addView(text(a.second,15f,true).apply { gravity=Gravity.CENTER })
                tile.addView(text(a.third,11f,false,Color.rgb(207,213,230)).apply { gravity=Gravity.CENTER })
                tile.setOnClickListener { if(index==1||index==2) launch(CartesiaActivity::class.java) else launch(StudioActivity::class.java) }
                val lp=LinearLayout.LayoutParams(0,dp(130),1f).apply { setMargins(if(col==1)dp(5) else 0,0,if(col==0)dp(5) else 0,0) }
                line.addView(tile,lp)
            }
            root.addView(line);space(root,10)
        }
        val info=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(12),dp(14),dp(12));background=shape(panel) }
        info.addView(text("✓  Recording  •  Noise reduction  •  MP3",14f,true,cyan))
        space(info,4);info.addView(text("Voice cloning needs a supported provider account and your own authorized voice sample.",12f,false,Color.LTGRAY))
        root.addView(info);space(root,14)
        val legacy=Button(this).apply { text="OPEN FULL AUDIO TOOLS  ›";background=shape(Color.rgb(39,92,180));setTextColor(Color.WHITE);setOnClickListener { launch(StudioActivity::class.java) } }
        root.addView(legacy,LinearLayout.LayoutParams(-1,dp(50)))
    }
}
