package com.alam.voice

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.speech.tts.TextToSpeech
import java.util.Locale
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.Manifest
import android.content.pm.PackageManager
import android.os.SystemClock
import java.io.File
import android.net.Uri
import android.provider.DocumentsContract
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var poem: EditText
    private lateinit var urlField: EditText
    private lateinit var codeField: EditText
    private lateinit var status: TextView
    private lateinit var mode: Spinner
    private lateinit var voice: Spinner
    private lateinit var emotion: Spinner
    private lateinit var tags: CheckBox
    private lateinit var rain: CheckBox
    private lateinit var flute: CheckBox
    private var audio: ByteArray? = null
    private var player: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recorder: MediaRecorder? = null
    private var recordingFile: File? = null
    private var recordedFile: File? = null
    private var recordingStart = 0L
    private var recorderStatus: TextView? = null
    private var processedRecording: ByteArray? = null
    private lateinit var noiseReduction: CheckBox
    private lateinit var echoEffect: CheckBox
    private val voices = arrayOf("Deep Male", "Emotional Male", "Funny Voice", "Baby Voice", "Cartoon Voice", "Female Voice", "Old Man Voice", "Narrator Voice")
    private val emotions = arrayOf("Nostalgic", "Sad", "Crying", "Happy", "Funny", "Calm")
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private fun bg(color:Int, radius:Float=20f):GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius=radius }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val navy=Color.rgb(18,29,57); val teal=Color.rgb(0,151,145); val muted=Color.rgb(91,106,130)
        val outer=ScrollView(this).apply { setBackgroundColor(Color.rgb(243,247,252)); isFillViewport=true }
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,22,18,28) }
        outer.addView(root); setContentView(outer)
        fun text(parent:LinearLayout, value:String, size:Float, color:Int=navy, bold:Boolean=false):TextView = TextView(this).apply {
            text=value; textSize=size; setTextColor(color); if(bold) setTypeface(null,Typeface.BOLD)
            parent.addView(this,LinearLayout.LayoutParams(-1,-2))
        }
        fun section(name:String, subtitle:String=""):LinearLayout {
            val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,17,18,18); background=bg(Color.WHITE) }
            val lp=LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=14 }; root.addView(card,lp)
            text(card,name,18f,navy,true)
            if(subtitle.isNotEmpty()) text(card,subtitle,12f,muted)
            return card
        }
        fun field(parent:LinearLayout,hint:String,value:String="",lines:Int=1):EditText=EditText(this).apply {
            this.hint=hint; setText(value); minLines=lines; if(lines>1) gravity=Gravity.TOP
            setTextColor(navy); textSize=15f; background=bg(Color.rgb(243,247,252),14f)
            setPadding(14,12,14,12)
            parent.addView(this,LinearLayout.LayoutParams(-1,-2).apply { topMargin=9 })
        }
        fun spinner(parent:LinearLayout,items:Array<String>):Spinner=Spinner(this).apply {
            adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,items)
            background=bg(Color.rgb(243,247,252),14f)
            parent.addView(this,LinearLayout.LayoutParams(-1,52).apply { topMargin=8 })
        }
        fun label(parent:LinearLayout,s:String) { text(parent,s,13f,muted,true).setPadding(0,14,0,0) }
        fun button(parent:LinearLayout,s:String,color:Int=teal,action:()->Unit) {
            val btn=Button(this).apply { text=s; isAllCaps=false; textSize=15f; setTextColor(Color.WHITE); background=bg(color,16f); setOnClickListener { action() } }
            parent.addView(btn,LinearLayout.LayoutParams(-1,52).apply { topMargin=10 })
        }
        val header=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,23,22,23); background=bg(navy,24f) }
        root.addView(header,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=16 })
        text(header,"✦  ALAM AI",26f,Color.WHITE,true)
        text(header,"VOICE STUDIO",16f,Color.rgb(112,229,213),true)
        text(header,"বাংলা লেখা থেকে কণ্ঠ তৈরি করুন",14f,Color.rgb(222,233,245)).setPadding(0,9,0,0)
        val writing=section("✍  আপনার লেখা","কবিতা, গল্প বা আবৃত্তির লেখা লিখুন")
        poem=field(writing,"এখানে বাংলা লেখা লিখুন", "বাবারা... তোমরা বড় হয়ো না! বৃষ্টিতে ভিজে নাও, প্রাণ খুলে হাসো।",5)
        val selection=section("🎙  Voice Collection","আপনার পছন্দের কণ্ঠ ও আবেগ বেছে নিন")
        label(selection,"Voice Mode")
        mode=spinner(selection,arrayOf("Free • Phone TTS (no server)","Premium • Server AI Voice"))
        label(selection,"Voice Style")
        voice=spinner(selection,voices)
        label(selection,"Emotion")
        emotion=spinner(selection,emotions)
        tags=CheckBox(this).apply { text="Auto Emotion Tags (server preview)"; isChecked=true; selection.addView(this) }
        val sounds=section("♫  Background Sound","AI Voice-এর মিউজিক মিক্সিং সার্ভার আপডেটের অপেক্ষায়")
        rain=CheckBox(this).apply { text="Rain ambience (recording processing)"; sounds.addView(this) }
        flute=CheckBox(this).apply { text="Soft musical tone (recording processing)"; sounds.addView(this) }
        val actions=section("▶  Create & Listen","Free মোডে ফোনের TTS দিয়ে শুনুন; MP3-এর জন্য সার্ভার প্রয়োজন")
        button(actions,"Generate / Speak Voice") { generate() }
        button(actions,"Play / Stop",navy) { playOrStop() }
        button(actions,"Save MP3",navy) { if(audio==null) status.text="MP3 তৈরি করতে Premium Server মোড ব্যবহার করুন" else startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="audio/mpeg"; putExtra(Intent.EXTRA_TITLE,"alam_recitation.mp3") },42) }
        button(actions,"Share MP3",navy) { shareAudio() }
        val recordCard=section("🎙  Audio Recorder", "নিজের কণ্ঠ রেকর্ড করুন • শুনুন • সেভ করুন • শেয়ার করুন")
        recorderStatus=text(recordCard,"● Ready to record • M4A high quality",13f,muted)
        button(recordCard,"●  Start Recording",Color.rgb(198,48,78)) { beginRecording() }
        button(recordCard,"■  Stop & Keep Recording",navy) { stopRecording() }
        button(recordCard,"▶  Play / Stop Recording") { playRecording() }
        button(recordCard,"↓  Save Recording (M4A)",navy) { saveRecording() }
        button(recordCard,"↗  Share Recording",navy) { shareRecording() }
        noiseReduction=CheckBox(this).apply { text="Noise reduction"; isChecked=true; recordCard.addView(this) }
        echoEffect=CheckBox(this).apply { text="Echo effect"; recordCard.addView(this) }
        button(recordCard,"✨  Process & Convert to MP3") { processRecording() }
        button(recordCard,"▶  Play Processed MP3",navy) { playProcessed() }
        button(recordCard,"↓  Save Processed MP3",navy) { saveProcessed() }
        button(recordCard,"↗  Share Processed MP3",navy) { shareProcessed() }
        val server=section("⚙  Premium Server Settings","শুধু Premium AI Voice ও MP3 তৈরির জন্য")
        label(server,"Backend HTTPS URL")
        urlField=field(server,"https://your-server.example",prefs.getString("url", "") ?: "")
        label(server,"Access code (not stored)")
        codeField=field(server,"Backend access code")
        button(server,"Save Server URL",muted) { prefs.edit().putString("url",urlField.text.toString().trim()).apply(); status.text="Server URL saved. Access code is not saved." }
        val info=section("Status")
        status=text(info,"Ready • Free TTS works with installed phone voices. Premium needs HTTPS server.",13f,muted)
        tts=TextToSpeech(this) { result ->
            ttsReady=result==TextToSpeech.SUCCESS
            if(ttsReady) tts?.language=Locale("bn","BD")
        }
    }
    private fun recorderMessage(message:String) { recorderStatus?.text=message }
    private fun beginRecording() {
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),101)
            recorderMessage("Microphone permission দিন, তারপর Start চাপুন")
            return
        }
        if(recorder!=null) { recorderMessage("Recording চলছে; আগে Stop করুন"); return }
        try {
            player?.release(); player=null
            val f=File(cacheDir,"record_${System.currentTimeMillis()}.m4a")
            val r=MediaRecorder().apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(128000)
                setAudioSamplingRate(44100)
                setOutputFile(f.absolutePath)
                prepare(); start()
            }
            recordingFile=f; recorder=r; processedRecording=null; recordingStart=SystemClock.elapsedRealtime()
            recorderMessage("🔴 Recording চলছে... Stop চাপুন")
        } catch(e:Exception) { recorder?.release(); recorder=null; recorderMessage("Record failed: ${e.message}") }
    }
    private fun stopRecording() {
        val r=recorder ?: run { recorderMessage("Recording চলছে না"); return }
        recorder=null
        try {
            r.stop()
            recordedFile=recordingFile
            val seconds=(SystemClock.elapsedRealtime()-recordingStart)/1000
            recorderMessage("✓ ${seconds}s recording ready • Play, Save or Share")
        } catch(e:Exception) { recordingFile?.delete(); recorderMessage("Recording too short or failed; try again") }
        finally { r.release(); recordingFile=null }
    }
    private fun playRecording() {
        if(player!=null) { player?.release(); player=null; recorderMessage("Playback stopped"); return }
        val f=recordedFile?.takeIf { it.exists() } ?: run { recorderMessage("আগে Record করুন"); return }
        try {
            player=MediaPlayer().apply {
                setDataSource(f.absolutePath); prepare()
                setOnCompletionListener { it.release(); player=null; recorderMessage("Playback finished") }
                start()
            }
            recorderMessage("▶ Playing recording")
        } catch(e:Exception) { recorderMessage("Playback failed: ${e.message}") }
    }
    private fun saveRecording() {
        if(recordedFile?.exists()!=true) { recorderMessage("আগে Record করুন"); return }
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type="audio/mp4"
            putExtra(Intent.EXTRA_TITLE,"alam_recording_${System.currentTimeMillis()}.m4a")
        },43)
    }
    private fun shareRecording() {
        val f=recordedFile?.takeIf { it.exists() } ?: run { recorderMessage("আগে Record করুন"); return }
        try {
            val shareFile=File(cacheDir,"shared_recording.m4a"); f.copyTo(shareFile,overwrite=true)
            val uri=Uri.parse("content://${packageName}.audio/shared_recording.m4a")
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type="audio/mp4"; putExtra(Intent.EXTRA_STREAM,uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            },"Share recording"))
        } catch(e:Exception) { recorderMessage("Share failed: ${e.message}") }
    }
    private fun processRecording() {
        val file=recordedFile?.takeIf { it.exists() } ?: run { recorderMessage("আগে রেকর্ড করুন"); return }
        val base=urlField.text.toString().trim().trimEnd('/')
        val access=codeField.text.toString()
        if(!base.startsWith("https://") || access.isBlank()) { recorderMessage("MP3 processing-এর জন্য HTTPS server ও access code দিন"); return }
        val query="denoise=${noiseReduction.isChecked}&echo=${echoEffect.isChecked}&rain=${rain.isChecked}&tone=${flute.isChecked}"
        recorderMessage("Processing recording...")
        executor.execute {
            try {
                val conn=(URL("$base/process-recording?$query").openConnection() as HttpURLConnection).apply {
                    requestMethod="POST"; doOutput=true; connectTimeout=15000; readTimeout=120000
                    setRequestProperty("Content-Type","audio/mp4")
                    setRequestProperty("X-Access-Code",access)
                    setFixedLengthStreamingMode(file.length())
                }
                conn.outputStream.use { output -> file.inputStream().use { it.copyTo(output) } }
                val bytes=if(conn.responseCode in 200..299) conn.inputStream.use { it.readBytes() }
                    else throw Exception("Server HTTP ${conn.responseCode}")
                conn.disconnect()
                runOnUiThread { processedRecording=bytes; recorderMessage("MP3 ready • Play, Save or Share") }
            } catch(e:Exception) { runOnUiThread { recorderMessage("Processing failed: ${e.message}") } }
        }
    }
    private fun playProcessed() {
        val bytes=processedRecording ?: run { recorderMessage("আগে Process & Convert চাপুন"); return }
        try {
            player?.release(); player=null
            val file=File(cacheDir,"processed_recording.mp3"); file.writeBytes(bytes)
            player=MediaPlayer().apply { setDataSource(file.absolutePath); prepare(); setOnCompletionListener { it.release(); player=null }; start() }
            recorderMessage("Playing processed MP3")
        } catch(e:Exception) { recorderMessage("Playback failed: ${e.message}") }
    }
    private fun saveProcessed() {
        if(processedRecording==null) { recorderMessage("আগে MP3 তৈরি করুন"); return }
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type="audio/mpeg"
            putExtra(Intent.EXTRA_TITLE,"alam_recording_${System.currentTimeMillis()}.mp3")
        },44)
    }
    private fun shareProcessed() {
        val bytes=processedRecording ?: run { recorderMessage("আগে MP3 তৈরি করুন"); return }
        try {
            File(cacheDir,"shared_processed.mp3").writeBytes(bytes)
            val uri=Uri.parse("content://${packageName}.audio/shared_processed.mp3")
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type="audio/mpeg"; putExtra(Intent.EXTRA_STREAM,uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            },"Share MP3"))
        } catch(e:Exception) { recorderMessage("Share failed: ${e.message}") }
    }
    private fun generate() {
        if(mode.selectedItemPosition==0) {
            val input=poem.text.toString().trim()
            if(input.isEmpty()) { status.text="প্রথমে কিছু লিখুন"; return }
            if(!ttsReady) { status.text="Phone TTS is loading or unavailable"; return }
            audio=null
            tts?.setPitch(if(voice.selectedItemPosition==3) 1.35f else if(voice.selectedItemPosition==4) 1.2f else 1.0f)
            tts?.setSpeechRate(if(emotion.selectedItemPosition==1) 0.85f else 1.0f)
            val result=tts?.speak(input,TextToSpeech.QUEUE_FLUSH,null,"alam_free")
            status.text=if(result==TextToSpeech.SUCCESS) "Free voice playing • MP3 export requires backend" else "TTS failed; install a Bengali voice in phone settings"
            return
        }
        val base=urlField.text.toString().trim().trimEnd('/')
        val code=codeField.text.toString()
        val input=poem.text.toString().trim()
        if(!base.startsWith("https://") || code.isBlank() || input.isBlank()) { status.text="Enter HTTPS server URL, access code and text"; return }
        val selected=voice.selectedItemPosition
        val payload=JSONObject().put("text",input).put("mode",if(mode.selectedItemPosition==0) "free" else "premium")
            .put("voice",if(selected==5) "female" else "male").put("style",voices[selected].lowercase().replace(' ','_'))
            .put("emotion",emotions[emotion.selectedItemPosition].lowercase()).put("auto_tags",tags.isChecked)
        status.text="Generating..."
        executor.execute {
            try {
                val conn=(URL("$base/synthesize").openConnection() as HttpURLConnection).apply {
                    requestMethod="POST"; connectTimeout=15000; readTimeout=120000; doOutput=true
                    setRequestProperty("Content-Type","application/json; charset=utf-8")
                    setRequestProperty("X-Access-Code",code)
                }
                conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
                val result=if(conn.responseCode in 200..299) conn.inputStream.use { it.readBytes() } else throw Exception("Server returned HTTP ${conn.responseCode}: ${conn.errorStream?.bufferedReader()?.readText()?.take(180)}")
                conn.disconnect()
                runOnUiThread { audio=result; status.text="Audio ready (${result.size/1024} KB). Play or save MP3." }
            } catch(e:Exception) { runOnUiThread { status.text="Failed: ${e.message}" } }
        }
    }
    private fun playOrStop() {
        if(tts?.isSpeaking==true) { tts?.stop(); status.text="Stopped"; return }
        if(player!=null) { player?.release(); player=null; status.text="Stopped"; return }
        val bytes=audio ?: run { status.text="Generate audio first"; return }
        try {
            val file=java.io.File(cacheDir,"preview.mp3"); file.writeBytes(bytes)
            player=MediaPlayer().apply { setDataSource(file.absolutePath); prepare(); setOnCompletionListener { it.release(); player=null }; start() }
            status.text="Playing"
        } catch(e:Exception) { status.text="Playback failed: ${e.message}" }
    }
    private fun shareAudio() {
        val bytes=audio ?: run { status.text="Generate audio first"; return }
        try {
            val file=java.io.File(cacheDir,"shared_recitation.mp3"); file.writeBytes(bytes)
            // Use a content provider rather than exposing a file:// URI.
            val uri=Uri.parse("content://${packageName}.audio/shared_recitation.mp3")
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type="audio/mpeg"; putExtra(Intent.EXTRA_STREAM,uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) },"Share audio"))
        } catch(e:Exception) { status.text="Share failed: ${e.message}" }
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==44 && resultCode==RESULT_OK) {
            try {
                val uri=data?.data ?: throw Exception("No destination")
                val bytes=processedRecording ?: throw Exception("No processed MP3")
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: throw Exception("Cannot save")
                recorderMessage("MP3 saved")
            } catch(e:Exception) { recorderMessage("MP3 save failed: ${e.message}") }
        }
        if(requestCode==43 && resultCode==RESULT_OK) {
            val f=recordedFile ?: return
            try {
                val destination=data?.data ?: throw Exception("No destination")
                contentResolver.openOutputStream(destination)?.use { output -> f.inputStream().use { it.copyTo(output) } }
                    ?: throw Exception("Cannot open destination")
                recorderMessage("✓ Recording saved as M4A")
            } catch(e:Exception) { recorderMessage("Save failed: ${e.message}") }
        }
        if(requestCode==42 && resultCode==RESULT_OK) {
            val bytes=audio ?: return
            try { data?.data?.let { contentResolver.openOutputStream(it)?.use { out->out.write(bytes) } }; status.text="MP3 saved" }
            catch(e:Exception) { status.text="Save failed: ${e.message}" }
        }
    }
    override fun onDestroy() { recorder?.run { try { stop() } catch(_:Exception) {} ; release() }; tts?.stop(); tts?.shutdown(); player?.release(); executor.shutdownNow(); super.onDestroy() }
}
