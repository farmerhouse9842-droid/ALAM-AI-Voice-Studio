"""Authenticated audio processing using an installed FFmpeg executable."""
import os
import subprocess
import tempfile
from fastapi import APIRouter, Header, HTTPException, Request
from fastapi.responses import Response
from main import authorize

router = APIRouter()

@router.post('/process-recording')
async def process_recording(request: Request, x_access_code: str | None = Header(default=None)):
    authorize(request, x_access_code)
    if request.headers.get('content-type', '').split(';')[0] != 'audio/mp4':
        raise HTTPException(415, 'Expected audio/mp4')
    data = await request.body()
    if not 100 <= len(data) <= 20 * 1024 * 1024:
        raise HTTPException(413, 'Recording must be between 100 bytes and 20 MB')
    options = request.query_params
    denoise = options.get('denoise') == 'true'
    echo = options.get('echo') == 'true'
    rain = options.get('rain') == 'true'
    tone = options.get('tone') == 'true'
    with tempfile.TemporaryDirectory() as folder:
        src = os.path.join(folder, 'input.m4a')
        dst = os.path.join(folder, 'output.mp3')
        with open(src, 'wb') as f: f.write(data)
        inputs = ['-i', src]
        filters = []
        chain = '[0:a]highpass=f=85,lowpass=f=12000'
        if denoise: chain += ',afftdn=nf=-25'
        if echo: chain += ',aecho=0.8:0.35:110:0.2'
        chain += '[voice]'
        filters.append(chain)
        tracks = ['[voice]']
        if rain:
            idx = 1 + int(tone)
            inputs += ['-f', 'lavfi', '-i', 'anoisesrc=color=pink:amplitude=0.018:sample_rate=44100']
            # Pink noise is a synthetic ambience, not a real rain recording.
            filters.append(f'[{idx}:a]lowpass=f=1200,volume=0.20[rain]')
            tracks.append('[rain]')
        if tone:
            inputs += ['-f', 'lavfi', '-i', 'sine=frequency=523.25:sample_rate=44100']
            filters.append('[1:a]volume=0.035[tone]')
            tracks.append('[tone]')
        if len(tracks)>1:
            filters.append(''.join(tracks)+f'amix=inputs={len(tracks)}:duration=first:dropout_transition=0[out]')
            output_map = '[out]'
        else: output_map = '[voice]'
        cmd = ['ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'error', '-y', *inputs, '-filter_complex', ';'.join(filters), '-map', output_map, '-vn', '-codec:a', 'libmp3lame', '-b:a', '160k', '-t', '600', dst]
        try:
            result = subprocess.run(cmd, capture_output=True, timeout=90, check=False)
        except (OSError, subprocess.TimeoutExpired):
            raise HTTPException(503, 'FFmpeg unavailable or processing timed out')
        if result.returncode != 0 or not os.path.exists(dst):
            raise HTTPException(422, 'Unable to process this recording')
        with open(dst, 'rb') as f: processed = f.read()
    return Response(content=processed, media_type='audio/mpeg')
