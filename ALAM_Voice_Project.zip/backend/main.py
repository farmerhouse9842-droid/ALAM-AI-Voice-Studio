import os, base64, secrets, time, threading
from collections import defaultdict, deque
import httpx
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel, Field

app = FastAPI(title="ALAM AI Voice Backend", docs_url=None, redoc_url=None)
requests_by_ip = defaultdict(deque)
lock = threading.Lock()

class VoiceRequest(BaseModel):
    text: str = Field(min_length=1, max_length=2500)
    mode: str = "free"
    emotion: str = "nostalgic"
    voice: str = "male"
    style: str = "deep_male"
    auto_tags: bool = True

def authorize(request: Request, pin: str | None):
    configured = os.environ.get("APP_ACCESS_PIN", "")
    if not configured or not pin or not secrets.compare_digest(pin, configured):
        raise HTTPException(401, "Invalid access code")
    ip = request.client.host if request.client else "unknown"
    now = time.monotonic()
    with lock:
        q = requests_by_ip[ip]
        while q and now - q[0] > 3600: q.popleft()
        if len(q) >= int(os.getenv("HOURLY_LIMIT", "15")):
            raise HTTPException(429, "Hourly limit reached")
        q.append(now)

@app.get("/health")
def health(): return {"status": "ok"}

@app.post("/synthesize")
async def synthesize(body: VoiceRequest, request: Request, x_access_code: str | None = Header(default=None)):
    authorize(request, x_access_code)
    if body.mode == "free":
        key = os.getenv("GOOGLE_TTS_API_KEY")
        if not key: raise HTTPException(503, "Google TTS is not configured")
        # Bengali voices are selected by language and gender. Google chooses an available voice.
        payload = {"input": {"text": body.text}, "voice": {"languageCode": "bn-IN", "ssmlGender": "MALE" if body.voice == "male" else "FEMALE"}, "audioConfig": {"audioEncoding": "MP3", "speakingRate": 1.12 if body.emotion in ("funny", "happy") else (0.86 if body.emotion in ("sad", "crying", "nostalgic") else 1.0), "pitch": 5 if body.style in ("baby_voice", "cartoon_voice") else (-3 if body.style == "old_man_voice" else 0)}}
        async with httpx.AsyncClient(timeout=75) as client:
            r = await client.post("https://texttospeech.googleapis.com/v1/text:synthesize", params={"key": key}, json=payload)
        if r.status_code != 200: raise HTTPException(502, "Google voice generation failed; check credentials, quota and Bengali voice support")
        data = r.json().get("audioContent")
        if not data: raise HTTPException(502, "Empty Google audio response")
        return Response(content=base64.b64decode(data), media_type="audio/mpeg")
    if body.mode == "premium":
        key = os.getenv("ELEVENLABS_API_KEY")
        voice_id = os.getenv("ELEVENLABS_MALE_VOICE_ID" if body.voice == "male" else "ELEVENLABS_FEMALE_VOICE_ID")
        if not key or not voice_id: raise HTTPException(503, "ElevenLabs is not configured")
        # Emotion controls are voice settings, not text tags (which may be read aloud).
        # Expressiveness depends on the selected voice and supported ElevenLabs model.
        emotion_profiles = {
            "emotional recitation": (0.30, 0.72),
            "nostalgic": (0.35, 0.60),
            "sad": (0.38, 0.55),
            "crying": (0.30, 0.70),
            "romantic": (0.40, 0.52),
            "happy": (0.42, 0.65),
            "funny": (0.40, 0.70),
            "calm": (0.65, 0.20),
            "storytelling": (0.52, 0.40),
        }
        selected = body.emotion.lower().replace("_", " ")
        stability, style = emotion_profiles.get(selected, (0.42, 0.45))
        if not body.auto_tags:
            stability, style = 0.55, 0.0
        payload = {
            "text": body.text,
            "model_id": os.getenv("ELEVENLABS_MODEL_ID", "eleven_multilingual_v2"),
            "voice_settings": {
                "stability": stability,
                "similarity_boost": 0.78,
                "style": style,
                "use_speaker_boost": True,
            },
        }
        async with httpx.AsyncClient(timeout=100) as client:
            r = await client.post(f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}", headers={"xi-api-key": key, "accept": "audio/mpeg"}, json=payload)
        if r.status_code != 200: raise HTTPException(502, "ElevenLabs generation failed; check credentials, quota and voice ID")
        return Response(content=r.content, media_type="audio/mpeg")
    raise HTTPException(400, "Unknown voice mode")

from audio_processing import router as audio_router
app.include_router(audio_router)
